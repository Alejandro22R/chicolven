@echo off
REM Inicia Chicolven Vitrina y lo vuelve a abrir si se cierra por un error.
REM "Iniciar Chicolven.bat /auto" (usado al encender el PC) no abre el panel en el navegador.
cd /d "%~dp0"
title Chicolven Vitrina
if /i "%~1"=="/auto" set CHICOLVEN_NO_BROWSER=1
:loop
"%~dp0ChicolvenVitrina.exe"
echo.
echo El programa se detuvo. Se reiniciara en 5 segundos (cierre esta ventana para salir)...
set CHICOLVEN_NO_BROWSER=1
timeout /t 5 /nobreak >nul
goto loop
