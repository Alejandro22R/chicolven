@echo off
REM Hace que Chicolven Vitrina arranque solo (minimizado) al encender el PC.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w = New-Object -ComObject WScript.Shell; $p = [Environment]::GetFolderPath('Startup');" ^
  "$s = $w.CreateShortcut($p + '\Chicolven Vitrina.lnk'); $s.TargetPath = '%~dp0Iniciar Chicolven.bat'; $s.Arguments = '/auto';" ^
  "$s.WorkingDirectory = '%~dp0'; $s.WindowStyle = 7; $s.IconLocation = '%~dp0ChicolvenVitrina.exe,0'; $s.Save()"
echo.
set /p TV=Este PC tiene un televisor por HDMI? Escriba el numero de pantalla para abrirla al iniciar (o Enter para omitir):
if "%TV%"=="" goto done
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w = New-Object -ComObject WScript.Shell; $p = [Environment]::GetFolderPath('Startup');" ^
  "$s = $w.CreateShortcut($p + '\Chicolven TV %TV%.lnk'); $s.TargetPath = '%~dp0Abrir TV en este PC.bat'; $s.Arguments = '%TV%';" ^
  "$s.WorkingDirectory = '%~dp0'; $s.WindowStyle = 7; $s.Save()"
:done
echo.
echo Listo. Chicolven Vitrina se abrira solo al encender el PC.
pause
