@echo off
REM Abre una pantalla en modo kiosko (pantalla completa) en un monitor o TV conectado por HDMI.
REM Uso: "Abrir TV en este PC.bat" 1        -> TV 1 en el monitor principal
REM      "Abrir TV en este PC.bat" 2 1920   -> TV 2 en el segundo monitor (a la derecha)
setlocal
cd /d "%~dp0"
set SCREEN=%1
if "%SCREEN%"=="" set /p SCREEN=Numero de pantalla a abrir (1, 2, 3...):
if "%SCREEN%"=="" set SCREEN=1
set POSX=%2
if "%POSX%"=="" set POSX=0
set PORT=3000
for /f "tokens=2 delims==" %%a in ('findstr /b /i "PORT=" config.ini') do set PORT=%%a
set BROWSER="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not exist %BROWSER% set BROWSER="C:\Program Files\Google\Chrome\Application\chrome.exe"
start "" %BROWSER% --kiosk "http://localhost:%PORT%/tv/%SCREEN%" --edge-kiosk-type=fullscreen ^
  --user-data-dir="%LOCALAPPDATA%\ChicolvenKiosko\tv%SCREEN%" --window-position=%POSX%,0 ^
  --no-first-run --disable-extensions --disable-translate --autoplay-policy=no-user-gesture-required ^
  --ignore-gpu-blocklist --enable-gpu-rasterization --noerrdialogs --disable-session-crashed-bubble
