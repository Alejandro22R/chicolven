@echo off
powershell -NoProfile -Command "Get-ChildItem ([Environment]::GetFolderPath('Startup')) -Filter 'Chicolven*.lnk' | Remove-Item"
echo Listo: Chicolven Vitrina ya no arranca solo.
pause
